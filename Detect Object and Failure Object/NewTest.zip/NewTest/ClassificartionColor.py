import cv2
import numpy as np

def classification(imgageDurian):
    # Convert Bitmap to OpenCV Mat
    frame = cv2.cvtColor(np.array(imgageDurian), cv2.COLOR_BGR2GRAY)
    frame = cv2.medianBlur(imgageDurian, 3)

    # Thresholding
    _, thresh = cv2.threshold(imgageDurian, 60, 255, cv2.THRESH_BINARY_INV)

    # Find contours
    contours, _ = cv2.findContours(imgageDurian, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    max_area = 0
    for contour in contours:
        # Calculate bounding rectangle
        x, y, w, h = cv2.boundingRect(contour)
        
        # Count white pixels within the bounding rectangle
        dem = np.sum(thresh[y:y+h, x:x+w] == 255)

        # Update max area and calculate the real area
        if dem > max_area:
            max_area = dem
            area = max_area * (1369 / 4260) * (851 / 2810) * 0.01

    return area <= 2

# Example usage:
# Assuming you have a Bitmap object called ImageDurian
# result = classification(Durian)
